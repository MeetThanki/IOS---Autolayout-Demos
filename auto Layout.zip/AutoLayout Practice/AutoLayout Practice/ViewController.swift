//
//  ViewController.swift
//  AutoLayout Practice
//
//  Created by Meet Thanki on 01/09/19.
//  Copyright © 2019 Meet Thanki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

